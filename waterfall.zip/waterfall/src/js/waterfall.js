(function () {
    var oLi = document.getElementsByClassName('box'),
        flag = false,
        num = 1,
        initWidth = 200;
    function getData() {
        if(!flag) {
            flag = true;
            ajax('GET', 'http://localhost/waterfall/src/js/getPics.php', addDom, 'cpage=' + num, true);
            num++;
        }
    }
    getData();
    function addDom(data) {
        var dataList = JSON.parse(data);
        if(dataList.length > 0) {
            dataList.forEach(function (ele, index) {
                var oItem = document.createElement('div'),
                    oImg = new Image(),
                    oP = document.createElement('p'),
                    oCont = document.createElement('div'),
                    minIndex = getMinList(oLi);

                    oCont.className = 'cont';
                    oCont.style.height = ele.height * initWidth / ele.width;
                    oItem.className = 'item';
                    oImg.src = ele.preview;
                    oImg.height = ele.height * initWidth / ele.width;
                    oP.innerText = ele.title;

                    oImg.onerror = function () { //谷歌图片加载出错会有边框去不掉的，只能通过变宽后移位遮挡掉
                        this.width = '202px';
                        this.style.margin = '-1px';
                        oImg.height = ele.height * initWidth / ele.width + 2;
                    }
                    oCont.appendChild(oImg);
                    oItem.appendChild(oCont);
                    oItem.appendChild(oP);
                    oLi[minIndex].appendChild(oItem);
            })
            flag = false;
        }
    }
    function getMinList(dom) {
        var minHeight = dom[0].offsetHeight,
            i = 1,
            index = 0;
        for(; i < dom.length; i++) {
            var minH = dom[i].offsetHeight;
            if(minH < minHeight) { //offsetHeightd等属性会重新根据页面的布局计算值，比较耗性能
                minHeight = minH;
                index = i;
            }
        }
        return index;
    }

    window.onscroll = function () {
        var srcollHeight = document.documentElement.scrollTop || document.body.scrollTop,
            clientHeight = document.documentElement.clientHeight || document.body.clientHeight,
            pageHeight = oLi[getMinList(oLi)].offsetHeight;
        if(srcollHeight + clientHeight > pageHeight) {
            getData();
        }
    }
})()