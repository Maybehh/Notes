var UglifyJSPlugin = require('uglifyjs-webpack-plugin');
var webpack = require('webpack');
var ExtractTextPlugin = require("extract-text-webpack-plugin");
var providePlugin = new webpack.ProvidePlugin({$: 'jquery', jQuery: 'jquery', 'window.jQuery': 'jquery'});

module.exports = {
    entry: {
        index: './src/js/entry.js',  //index是html的名字
        index2: './src/js/entry2.js'
    },
    output: {
        filename: '[name].js',  //[name]表示生成文件按照entry的属性名命名
        //'[name]-[hash:8].js'  每个模块文件hash值是每次webpack（不论是否有修改的模块文件）都会改变的，而chunkhash则是仅有修改的模块文件才会改变
        path: __dirname + '/out',   //__dirname表示当前文件所在的绝对目录
        publicPath: 'http://localhost:8080/out'
    },
    module: {
        rules: [
            {test: /.js$/, use: ['babel-loader']},
            // {test: /.css$/, use: ['style-loader', 'css-loader']}, //从后往前解析
            // {
            //     test: /\.css$/,
            //     use: ExtractTextPlugin.extract({
            //       fallback: "style-loader",
            //       use: "css-loader"
            //     })
            // },
            {test: /.jpg|png|gif|svg/, use: ['url-loader?limit=8192&name=./[name].[ext]']},   //打包到服务器时要注意用./[name].[ext]而不是直接/[name].[ext]
            {test: /.less$/, use: ['style-loader','css-loader','less-loader']}

        ]
    },
    plugins: [
        new UglifyJSPlugin(),
        new webpack.optimize.CommonsChunkPlugin({
            name: "commons",
            filename: "commons.js",
            minChunks:2 //该文件有2个及以上就会被独立打包
        }),
        new ExtractTextPlugin("[name].css"),
        providePlugin
    ]
}