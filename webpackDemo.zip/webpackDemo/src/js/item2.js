require('../less/item2.less');
var item2 = {
    init: function () {
        this.bindEvent();
    },
    bindEvent: function () {
        document.getElementsByClassName('item2')[0].onclick = this.changeColor;
    },
    changeColor: function () {
        this.style.width = '200px';
    }
}
module.exports = item2;