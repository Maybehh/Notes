// require('../css/entry.css')  //加上style标签
require('../less/entry.less');
var tool = require('./tool.js');
tool.hello('hello');

var oImg = new Image();  //引入base64位文件
oImg.src = require('../img/1.jpg');
document.body.appendChild(oImg);

require('jquery');
console.log($(oImg));

var item1 = require('./item1.js');
item1.init();
var item2 = require('./item2.js');
item2.init();