require('../css/entry.css')  //加上style标签

var tool = require('./tool.js');
tool.hello('hello');

var oImg = new Image();  //引入base64位文件
oImg.src = require('../img/1.jpg');
document.body.appendChild(oImg);