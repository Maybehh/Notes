module.exports = {
    hello: function (str) {
        console.log(str);
    }
}