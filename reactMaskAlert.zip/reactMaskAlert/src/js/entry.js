// require('../less/entry.less');
var React = require('react');
var ReactDom = require('react-dom');

var Mask = React.createClass({
    getDefaultProps: function () {
        return {
            style: {
                width: '100%',
                opacity: 0.5,
                background: '#000',
                position: 'absolute',  //因为没有已定位的父级元素，因此以document文档对齐
                left: 0,
                right: 0,
                top: 0,
                bottom: 0,
                display: 'none'
            }
        }
    },
    render: function () {
        var style = Object.assign({}, this.props.style);  //props是只读属性，不要改动，会报错
        if(this.props.openFlag) {
            style.display = 'block';
        }
        return (
            <div style={style}>
                {/* <Info></Info>   把Info组件放进来 */}
                {this.props.children}  {/*表示这里面是可以放子组件的，但没有明确放哪一个*/}
            </div>
        )
    }
});

var Info = React.createClass({
    getDefaultProps: function () {
        return {
            message: 'Hello World',
            style: {
                margin: '100px auto',
                textAlign: 'center',
                height: '150px',
                lineHeight: '150px',
                color: '#f00',
                backgroundColor: '#f40'
            }
        }
    },
    render: function () {
        return (
            <div onClick={this.props.onHandleClick} style={this.props.style}>{this.props.message}</div>
        )
    }
});

var ButtonDialog = React.createClass({
    getInitialState: function () {
        return {
            open: false
        }
    },
    onChangeState: function () {
        var flag = !this.state.open;
        this.setState({
            open: flag
        })
    },
    render: function () {
        return (
            <div>
                <button onClick={this.onChangeState}>Dialog</button>
                <Mask openFlag={this.state.open}>
                    <Info onHandleClick={this.onChangeState}></Info>  {/*onChangeState方法中的this绑定的是ButtonDialog这个组件，是不会改变的，传到Info组件中使用时改变的是ButtonDialog这个组件的open，因此重新渲染（这个是类而不是dom节点，是固定绑定的，而不是说谁调用就指向谁）*/}
                </Mask>
            </div>
        )
    }
});

ReactDom.render(
    <ButtonDialog/>,
    document.getElementById('root')  //不能直接装到body里，即不能document.body
)

//通过命令行touch .gitignore 创建.gitignore文件，在.gitignore文件中写上node_modules，就可以在上传时忽略这个文件了