var setLocal = {
    save(key, value){
        localStorage.setItem(key, JSON.stringify(value));
    },
    get(key) {
        return JSON.parse(localStorage.getItem(key));
    }
}
var filterChecked = {
    all(list) {
        return list;
    },
    finish(list) {
        return list.filter(function (item) {
            return item.checked;
        })
    },
    unfinish(list) {
        return list.filter(function (item) {
            return !item.checked;
        })
    }
}
var list = setLocal.get('todo') || [];
var vm = new Vue({
    el: ".main",
    watch: {//监听
        // list: function () {  不能监听list里面的变化
        //     setLocal.save('todo', this.list);
        // }
        list: {  //可以监听list里面的变化
            deep: true,
            handler: function () {
                setLocal.save('todo', this.list);
            }
        }
    },
    data: {
        list: list,
        inputValue: '',
        editingtodo: '',
        beforeEditing: '',
        visibility: 'all'
    },
    computed: {
        filterList() {
            return this.list.filter(function(item){return !item.checked}).length;
        },
        filterCheck() {
            return filterChecked[this.visibility] ? filterChecked[this.visibility](this.list) : this.list;
        }
    },
    methods: {
        // filter() {
        //     return this.list.filter(function(item){return !item.checked}).length
        // },
        addTodo(event) {
            this.list.push({ //数组方法的push vue是不能监测到的，因此vue重写了push方法，这里的push方法vue是可以监测到的
                title: this.inputValue,
                checked: false
            });
            this.inputValue = ''
        },
        deleteTodo(todo){
            var index = this.list.indexof(todo);
            this.list.splice(index, 1); //同样splice也是重写的
        },
        editTodo(todo){
            this.editingtodo = todo;
            this.beforeEditing = todo.title;
        },
        editedTodo() {
            this.editingtodo = '';
        },
        cancelEdit(todo) {
            todo.title = this.beforeEditing;
            this.beforeEditing = '';
            this.editingtodo = '';
        }
    },
    directives: {  //自定义指令
        focus: {
            update(el, binding) { //update函数失去或获得焦点都会触发
                if(binding.value) {
                    el.focus();
                }
            }
        }
    }
})

function hashchange () {
    var hash = window.location.hash.slice(1);
    vm.visibility = hash;
}
hashchange();
window.addEventListener('hashchange', hashchange);
