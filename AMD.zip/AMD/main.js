require.config({   //配置文件
    baseUrl: './',
    paths: {
        'jquery': 'jquery',   //不能写.js，会报错
        'math': 'math'
    }
})

require(['jquery', 'math'], function ($, math) {  //jquery和math模块全部加载完成后就会触发该函数
    console.log($());
    console.log(math.add(1, 2));
})