define(function () {
    return {
        a: "123"
    }
})