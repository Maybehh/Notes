var React = require('react');
var ReactDom = require('react-dom');
var data = [
    'Kobe',
    'Rose',
    'Curry',
    'Westbrook'
];
//首字母必须大写
var App = React.createClass({  //this代表这个组件
    getDefaultProps: function () {  //自己设置props
        console.log('getDefaultProps');
        return {
            name: 'cst'
        }
    },
    getInitialState: function () {  //组件状态
        console.log('getInitialState');
        return {
            open: true
        }
    },
    componentWillMount: function () {
        //在这个状态下获取ajax数据比较好
        console.log('componentWillMount');
    },
    componentDidMount: function () {
        console.log('componentDidMount');
    },
    shouldComponentUpdate: function (nextProps, nextState) {
        console.log('shouldComponentUpdate');
        console.log(nextProps, nextState);
        // if(nextState) {
        //     return false;
        // }
        return true;  //返回true或false确定能否渲染(生命周期图的该事件的后续事件是否能继续执行)
    },
    componentWillUpdate: function () {
        console.log('componentWillUpdate');
    },
    onChangeColor: function () {
        var flag = !this.state.open;
        this.setState({  //只有state改变了才会触发render重新渲染
            open: flag
        })
    },
    render: function () {
        var fontColor = {
            color: 'red'
        };
        if(!this.state.open) {
            fontColor.color = 'green';
        }
        var data = this.props.stars;
        return (
            <div className={'duyi'} id={'hhh'} style={fontColor}>
                <h1 onClick={this.onChangeColor}>NBA Star</h1>
                <ul>
                    {
                        data.map(function (ele, index) {
                            return <li key={index + 100}>{ele}</li>  //保证有唯一的key值，不然会报错
                        })
                    }
                </ul>
            </div>
        )
    }
});

ReactDom.render(
    <App stars={data}/>,  //data写入stars属性，stars属性写入App组件的props属性
    document.getElementById('root')
)