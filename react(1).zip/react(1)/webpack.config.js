var webpack = require('webpack');
var path = require('path');
module.exports = {
    entry: './src/js/entry.js',
    output: {
        path: path.resolve(__dirname, './static'),
        publicPath: 'http://localhost:8080/static/',
        filename: 'index.js'
    },
    module: {
        rules: [
            {test: /\.less$/, use: ["style-loader", "css-loader", "less-loader"]}, //多个loader用use
            {
                test: /\.js$/,
                loader: "babel-loader",  //单个loader就可以用loader
                exclude: /node_modules/,   //设置下面的query是在/node_modules/里面找
                query: {
                    presets: [
                        require.resolve('babel-preset-es2015'),  //直接写babel-preset-es2015也可
                        require.resolve('babel-preset-react'),
                        require.resolve('babel-preset-stage-0'),
                    ]
                }
            },
            {test: /\.(jpg|png)$/, loader: 'url-loader'}
        ]
    },
    devServer: {
        port: 8080,
        historyApiFallback: true,
        inline: true
    }
}