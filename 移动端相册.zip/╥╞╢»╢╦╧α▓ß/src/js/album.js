var total = 15,
    liWidth = ($('ul').width() - 24) / 4,
    activeIndex = undefined,
    ratio = $(window).height() / $(window).width();

function render() {
    var str = '';
    for(var i = 1; i <= total; i++) {
        str += '<li style="height:' + liWidth + 'px"><img src="src/image/' + i + '.jpg"/></li>';
    }
    $(str).appendTo($('.wrapper')).animate({opacity: 1}, 500);
}
render();

$('ul').on('tap', 'li', function () {
    activeIndex = $(this).index();
    show(activeIndex + 1);
});

function show(i) {
    $('.show').html('').show();
    var oImg = new Image();
    oImg.src = 'src/image/' + i + '.jpg';
    oImg.onload = function () {
        var h = this.height,   /*写成$(this).height()必须是图片已经显示出来的才能获取*/
            w = this.width;
        if(h / w > ratio) {
            $(this).appendTo($('.show')).css('height', '100%').animate({opacity: 1}, 500);
        }else {
            $(this).appendTo($('.show')).css('width', '100%').animate({opacity: 1}, 500);
        }
    }
}

$('.show')
    .on('tap', function () {
        $(this).hide();
    })
    .on('swipeLeft', function () {
        if(activeIndex < total - 1) {
            activeIndex++;
            show(activeIndex + 1);
        }
    })
    .on('swipeRight', function () {
        if(activeIndex > 0) {
            activeIndex--;
            show(activeIndex + 1);
        }
    })