var gulp = require('gulp');
var htmlclean = require('gulp-htmlclean');  //压缩html
var imgMin = require('gulp-imagemin');   //压缩图片
var uglify = require('gulp-uglify');    //压缩js
var strip = require('gulp-strip-debug');   //自动去除js中的console、debugger等
var concat = require('gulp-concat');   //拼接js文件
var less = require('gulp-less');   //less转css 嵌套的会被分出来等
var postcss = require('gulp-postcss');  //提交css的注意格式等
var autoprefixer = require('autoprefixer');   //css前缀
var cssnano = require('cssnano');    //压缩css
var connect = require('gulp-connect');   //服务器

var devMode = process.env.NODE_ENV == 'development';  //判断是否是开发环境还是生产环境(production)
 //export NODE_ENV==development 在cmd中配置为开发环境

var folder = {
    src: 'src/',  //开发目录文件夹
    dist: 'dist/'   //压缩打包后的目录文件夹
}

gulp.task('html', function () {
    var page = gulp.src(folder.src + 'html/*')
                   .pipe(connect.reload());
    if(!devMode) {
        page.pipe(htmlclean());
    }
    page.pipe(gulp.dest(folder.dist + 'html/'));
})

gulp.task('js', function () {
    var page = gulp.src(folder.src + 'js/*')
                   .pipe(connect.reload());
    if(!devMode) {
        page.pipe(strip())
            // .pipe(concat('main.js'))  //把js都按先后顺序拼接到main.js文件中
            .pipe(uglify());
    }
    page.pipe(gulp.dest(folder.dist + 'js/'));
})

gulp.task('css', function () {
    var options = [autoprefixer(), cssnano()];
    var page = gulp.src(folder.src + 'css/*')
                   .pipe(connect.reload())
                   .pipe(less());
    if(!devMode) {
        page.pipe(postcss(options));
    }
    page.pipe(gulp.dest(folder.dist + 'css/'));
})

gulp.task('images', function () {
    gulp.src(folder.src + 'images/*')
        .pipe(imgMin())
        .pipe(gulp.dest(folder.dist + 'images/'));
})

gulp.task('watch', function () {
    gulp.watch(folder.src + 'html/*', ['html']); //一改变html就执行task('html', function () {})
    gulp.watch(folder.src + 'css/*', ['css']);
    gulp.watch(folder.src + 'js/*', ['js']);
    gulp.watch(folder.src + 'images/*', ['images']);
})

gulp.task('server', function (){  //自动监听模块文件变化，服务端自动刷新gulp
    connect.server({
        port: '8090', //端口号默认是8080
        livereload: true  //浏览器自动刷新
    });
})

gulp.task('default', ['html', 'images', 'js', 'css', 'watch', 'server']);  //括号里的内容是在default执行前必须先执行完成的（按写的先后顺序）

