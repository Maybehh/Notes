function Abc() {
    var a = 1; 
    return a++;
}