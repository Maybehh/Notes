function Index() {
    var a = 10;
    var b = 6;
    console.log(1111);
}
debugger;
function Index2() {
    var n = 0;
    return n++;
}