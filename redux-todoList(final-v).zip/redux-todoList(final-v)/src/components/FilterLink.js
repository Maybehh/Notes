import React, {Component} from 'react';
import {Link} from 'react-router';

const FilterLink = ({children, filter}) => (
    <Link  //不会刷新页面
        to={filter=='all'?'/':filter}
        activeStyle={{
            color: 'black',
            textDecoration: 'none'
        }}
    >{children}</Link>
)

// class FilterLink extends Component {
//     render() {
//         // if(this.props.currentFilter == this.props.filter) {
//         //     return (
//         //         <span>{this.props.children}</span>
//         //     )
//         // }
//         return (
//             <a href="#" onClick={() => {
//                 this.props.onClick(this.props.filter);
//             }}>{this.props.children}</a>
//         )
//     }
// }

export default FilterLink;