import React, {Component} from 'react';
import AddTodo from '../containers/AddTodo.js';
import TodoList from '../containers/TodoList.js';
import Footer from '../containers/Footer.js';

class App extends Component {
    render() {
        return (
            <div>
                <AddTodo></AddTodo>
                {/* <TodoList filter={this.props.params.filter}></TodoList>path='/(:filter)'的filter会由Route传到这里App组件的params里 */}
                <TodoList></TodoList>
                <Footer></Footer>
            </div>
        )
    }
}

export default App;