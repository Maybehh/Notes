import React, {Component} from 'react';
import {connect} from 'react-redux';
import {toggleTodo, receiveTodos, fetchTodos} from '../actions';
import {withRouter} from 'react-router';
import {getVisibleTodos} from '../reducers/';
import {getIsFetching} from '../reducers/';
import {getErrorMessage} from '../reducers/';
import ErrorTip from '../components/ErrorTip';
// import {fetchTodos} from '../api/';  //export出来的是对象

class TodoList extends Component {
    componentDidMount() {
        this.fetchData();
    } 
    componentDidUpdate(prevProps) { //this.setState或this.props改变都会引起componentUpdate
        if(prevProps.filter !== this.props.filter) {
            this.fetchData();
        }
    }
    fetchData() {
        // fetchTodos(this.props.filter).then((response) => {
        //     this.props.onReceiveTodos(response);
        // })
        this.props.onFetchTodos(this.props.filter);
    }
    render() {
        // console.log(this.props.todos) [] 和 有数据的[1, undefined]  所以有数据遍历到undefined就会找不到completed属性, []可能因为空数组就不遍历所以不会报错
        //在由connect写的，没写入mapStateToProps的属性是不能获得的，结果是undefined
        const {todos, isFetching, errorMessage} = this.props;
        if(isFetching && todos.length <= 0) {
            return <div>
                loading...
            </div>
        }
        if(errorMessage && todos.length <= 0) {
            return <ErrorTip
                message = {errorMessage}
                onRetry = {() => {
                    this.fetchData();
                }}
            ></ErrorTip>
        }
        return (  
            <ul>
                {todos.map((todo) => {
                    return (
                        <li 
                            style={{
                                textDecoration: todo.completed ? 'line-through' : 'none'
                            }}
                            key={todo.id}
                            onClick={() => {
                                this.props.onClickTodo(todo.id);
                            }}>
                            {todo.text}
                        </li>
                    )
                })}
            </ul>
        )
    }
}

// const connect = (mapStateToProps, mapDispatchToProps) => {
//     return (WrapperComponent) => {
//         class Connect extends Component{
//             componentDidMount() {
//                 const store = this.context.store;
//                 this.unsubscribe = store.subscribe(() => {
//                     this.forceUpdate();  //dispatch后自动更新
//                 })
//             }
//             componentWillUnmount() {
//                 this.unsubscribe();
//             }
//             render() {
//                 const store = this.context.store;
//                 const stateProps = mapStateToProps(store.getState());
//                 const dispatchProps = mapDispatchToProps(store.dispatch);
//                 const props = Object.assign({}, stateProps, dispatchProps);

//                 return React.createElement(WrapperComponent, props);
//                 // return <WrapperComponent
//                 //             todos={props.todos}
//                 //             onClickTodo={props.onClickTodo}
//                 //        ></WrapperComponent>
//                 // return <WrapperComponent {...props}></WrapperComponent>
//             }
//         }

//         Connect.contextTypes = {
//             store: React.PropTypes.object
//         }

//         return Connect;
//     }
// }

const mapStateToProps = (state, ownProps) => {
    const filter = ownProps.params.filter || 'all';
    // console.log(state)  看state的变化
    return {
        // todos: getVisibleTodos(state.todos, state.visiableFilter)
        // todos: getVisibleTodos(state.todos, ownProps.params.filter || 'all')

        todos: getVisibleTodos(state, filter),  //这个函数在执行的时候因为idByFilter的属性根据具体情况记录在state里，点击切换筛选条件的时候返回得到的todos不同就会出现报错，具体的报错情况就是[]空数组和[undefined]的区别
        isFetching: getIsFetching(state, filter),
        errorMessage: getErrorMessage(state, filter),
        filter
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onClickTodo: (id) => {
            dispatch(toggleTodo(id))
        },
        onReceiveTodos: (response, filter) => {
            dispatch(receiveTodos(response, filter));
        },
        onFetchTodos: (filter) => {
            dispatch(fetchTodos(filter));
        }
    }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(TodoList));  //返回的不是TodoList组件而是被connect修饰过后的组件，因此在引用TodoList中写入参数，在TodoList组件中是无法直接获得的，参数是写在修饰过的TodoList组件中的ownProps