const byId = (state = {}, action) => {
    switch(action.type) {
        case 'ADD_TODO_SUCCESS':
        case 'TOGGLE_TODO_SUCCESS':
            let nextState = Object.assign({}, state);
            nextState[action.response.id] = action.response;
            return nextState;
        case 'FETCH_TODOS_SUCCESS':
            // nextState = {}  保存state则刷新组件的时候第一次render时有数据给筛选，不会是空，因此会马上有数据。马上显示数据是由原来的state，经过1秒才触发的recive_todo action，这个时候才从promise那里获得数据，state才改变，然后再渲染一次（在promise和render里都写了筛选功能的函数）
            // console.log(action.response);
            nextState = Object.assign({}, state);
            action.response.forEach((todo) => {
                nextState[todo.id] = todo;
            })
            return nextState;
        default: 
            return state;
    }
}

export default byId;
export const getTodo = (state, id) => state[id];