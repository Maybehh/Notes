import {combineReducers} from 'redux';
import byId, * as fromById from './byId';
import createList, * as fromList from './createList';

//通过当前id找到相应的todos
// const byId = (state = {}, action) => {
//     switch(action.type) {
//         case 'ADD_TODO':
//             let nextState = Object.assign({}, state);
//             nextState[action.id] = {
//                 id: action.id,
//                 text: action.text,
//                 completed: false
//             }
//             return nextState;
//         case 'TOGGLE_TODO':
//             state[action.id] = Object.assign({}, state[action.id], {
//                 completed: !state[action.id].completed
//             })
//             return state;
//         case 'RECEIVE_TODOS': 
//             nextState = {};
//             action.response.forEach((todo) => {
//                 nextState[todo.id] = todo;
//             })
//             return nextState;
//         default: 
//             return state;
//     }
// }
// const allIds = (state = [], action) => {
//     if('all' !== action.filter) {
//         return state;
//     }
//     switch(action.type) {
//         case 'ADD_TODO':
//            return [...state, action.id];
//         case 'RECEIVE_TODOS': 
//             return action.response.map(todo => todo.id);
//         default: 
//             return state;
//     }
// }
// const completedIds = (state = [], action) => {
//     if('completed' !== action.filter) {
//         return state;
//     }
//     switch(action.type) {
//         case 'ADD_TODO':
//            return [...state, action.id];
//         case 'RECEIVE_TODOS': 
//             return action.response.map(todo => todo.id);
//         default: 
//             return state;
//     }
// }
// const activeIds = (state = [], action) => {
//     if('active' !== action.filter) {
//         return state;
//     }
//     switch(action.type) {
//         case 'ADD_TODO':
//            return [...state, action.id];
//         case 'RECEIVE_TODOS': 
//             return action.response.map(todo => todo.id);
//         default: 
//         console.log('activedefault')
//             return state;
//     }
// }

const idsByFilter = combineReducers({
    all: createList('all'),
    completed: createList('completed'),
    active: createList('active')
})

const todos = combineReducers({
    byId,
    idsByFilter
})

// const todos = (state = [], action) => {
//     switch(action.type) {  //纯函数因此不要直接在state上改，具体原因看源码（state要不同的地址，在redux里是根据state的地址即===来判断state是否更新，如果在原来基础上改且返回的话，地址不变，redux认为state没有变化，就不会更新state值，在渲染过程中获取的state值也就没变
//         case 'ADD_TODO':
//             // state.push({
//             //     id: ++gid,
//             //     text: action.text, //传进来的是对象的话，在外界改变对象则这里的对象也会改（引用值）就会引起数据混乱
//             //     completed: false,
//             //     test: Object.assign({}, action.test)  解决方法1
//             // })

//             // let newstate = [].concat(state);
//             // newstate.push({
//             //     id: ++gid,
//             //     text: action.text,
//             //     completed: false
//             // });
//             // return newstate;   //结合源码理解return后赋给了store的state值，state因此更新

//             return [...state, {
//                 id: action.id,
//                 text: action.text,
//                 completed: false
//             }]
//         case 'TOGGLE_TODO':
//             return state.map((todo) => {
//                 if(todo.id == action.id) {
//                     return Object.assign({}, todo, {
//                         completed: !todo.completed
//                     })
//                 }
//                 return todo;
//             })
//         default: 
//             return state;
//     }
// }

export default todos;

// export const getAllTodos = (state) => {
//     return state.allIds.map(id => state.byId[id]);
// }

export const getVisibleTodos = (state, filter) => {
    return fromList.getIds(state.idsByFilter[filter]).map(id => fromById.getTodo(state.byId, id));
}

export const getIsFetching = (state, filter) => {
    return fromList.getIsFetching(state.idsByFilter[filter]);
}

export const getErrorMessage = (state, filter) => {
    return fromList.getErrorMessage(state.idsByFilter[filter]);
}