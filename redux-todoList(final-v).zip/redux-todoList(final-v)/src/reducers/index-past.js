// import {combineReducers} from 'redux';
// import todos, * as fromTodos from './todos.js';
// // import visiableFilter from './visiableFilter.js';

// // const combineReducers = (reducers) => {
// //     return (state = {}, action) => {
// //         let newState = {};
// //         Object.keys(reducers).forEach((key) => {
// //             newState[key] = reducers[key](state[key], action);
// //         })
// //         return newState;
// //     }
// // }

// // const combineReducers = (reducers) => {
// //     return (state = {}, action) => {
// //         return Object.keys(reducers).reduce((newState, key) => {
// //             newState[key] = reducers[key](state[key], action);
// //             return newState;
// //         }, {})
// //     }
// // }

// // const combineReducers = (reducers) => (state = {}, action) => Object.keys(reducers).reduce((newState, key) => {
// //         newState[key] = reducers[key](state[key], action);
// //         return newState;
// // }, {});

// export const getVisibleTodos = (state, filter) => {
//     const todos = fromTodos.getAllTodos(state.todos);  //selector传入reducer的state必须是该reducer的state，以保证reducer的独立性(修改外部的state时reducer函数不用更改，只需要改变传入的state)
//     // const todos = state.todos.allIds.map((id) => state.todos.byId[id]);
//     switch(filter) {
//         // case 'SHOW_ALL': 
//         case 'all':
//             return todos;
//         // case 'SHOW_COMPLETED':
//         case 'completed': 
//             return todos.filter((todo) => {
//                 return todo.completed;
//             })
//         // case 'SHOW_ACTIVE':
//         case 'active': 
//             return todos.filter((todo) => {
//                 return !todo.completed;
//             })
//         default: 
//             throw new Error('unknow filter');
//     }
// }

// export default combineReducers({
//     todos
//     // visiableFilter
// })