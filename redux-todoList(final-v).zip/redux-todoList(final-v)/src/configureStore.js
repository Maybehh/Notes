import {saveState, getState} from './localStorage.js';
import {throttle} from 'lodash';
import {createStore, applyMiddleware} from 'redux';
import rootReducer from './reducers/index';
import thunk from 'redux-thunk';
import createLogger from 'redux-logger';

// const addLoggerToDispatch = (store) => {
//     const next = store.dispatch;
//     return (action) => {
//         console.log('----------------------');
//         console.log('Current state: ', store.getState());
//         console.log('Action: ', action);
//         const ret = next(action);
//         console.log('Next state: ', store.getState());
//     }
// }

// const addThunkToDispatch = (store) => {
//     const next = store.dispatch;
//     return (action) => {
//         if(typeof action == 'function') {
//             action(store.dispatch);
//         }else {
//             next(action);
//         }
//     }
// }

// const wrapDispatch = (store, middlewares) => {
//     middlewares.forEach((middlewares) => {
//         store.dispatch = middlewares(store);
//     })
// }

const configureStore = () => {
    // const mockData = getState();
    let store = createStore(rootReducer/*, mockData*/, applyMiddleware(thunk, createLogger()));

    // store.subscribe(throttle(() => {
    //     saveState(store.getState());
    // }, 1000))  //最快1秒执行一次

    //监控每个action
    // store.dispatch = addLoggerToDispatch(store);
    
    // store.dispatch = addThunkToDispatch(store);
    
    // const middlewares = [addLoggerToDispatch, addThunkToDispatch];
    // wrapDispatch(store, middlewares);

    return store;
}

export default configureStore;