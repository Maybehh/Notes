export const saveState = (state) => {
    //网络操作传输的都是二进制，因此得把数据序列化（变成字符串等可传输的形式）
    try{
        const data = JSON.stringify({
            todos: state.todos
        });
        localStorage.setItem('state', data);
    }catch(err) {
        return undefined;
    }
}

export const getState = () => {
    try{
        const state = JSON.parse(localStorage.getItem('state'));
        if(state == null) {
            return undefined;
        }
        return state;
    }catch(err){
        return undefined;
    }
}