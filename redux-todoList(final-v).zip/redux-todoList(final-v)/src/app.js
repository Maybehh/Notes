import ReactDom from 'react-dom';
import React from 'react';
import Root from './components/Root.js';
import configureStore from './configureStore.js';
//reducer是纯函数，不要改变传入的参数和影响外部环境

// const mockState = {  //初始化state
//     todos: [{
//         text: 'Mango',
//         id: 1,
//         completed: false
//     }, {
//         text: 'Mango',
//         id: 2,
//         completed: true
//     }],
//     visiableFilter: 'SHOW_ACTIVE'
// }
// let store = createStore(rootReducer, mockState);

// let test = {
//     name: 'level 1'
// }

// test.name = 'level 2';

// class Provider extends Component{
//     getChildContext() {
//         return {store: this.props.store};
//     }
//     render() {
//         return (
//             this.props.children
//         )
//     }
// }

// Provider.childContextTypes = {
//     store: React.PropTypes.object
// }

const render = () => {
    ReactDom.render(
        <Root store={configureStore()}></Root>,
        document.getElementById('root')
    )
}

render();

// store.subscribe(render);