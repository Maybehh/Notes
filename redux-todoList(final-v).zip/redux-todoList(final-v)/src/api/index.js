import {v4} from 'node-uuid';

const delay = (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

const mockData = [{
    id: v4(),
    text: 'mango1',
    completed: false
}, {
    id: v4(),
    text: 'mango2',
    completed: false
}, {
    id: v4(),
    text: 'mango3',
    completed: true
}, {
    id: v4(),
    text: 'mango4',
    completed: true
}, {
    id: v4(),
    text: 'mango5',
    completed: false
}]

export const fetchTodos = (filter) => {
    return delay(1000).then(() => {
        if(Math.random() > 0.5) {
            throw new Error('blood boom');
        }
        switch(filter) {
            case 'all':
                return mockData;
            case 'completed': 
                return mockData.filter((todo) => {
                    return todo.completed;
                })
            case 'active': 
                return mockData.filter((todo) => {
                    return !todo.completed;
                })
            default: 
                throw new Error('unknow filter');
        }
    })
}

export const addTodo = (text) => {
    return delay(1000).then(() => {
        const todo = {
            id: v4(),
            completed: false,
            text
        }
        mockData.push(todo);
        return todo;
    })
}

export const toggleTodo = (id) => {
    return delay(1000).then(() => {
        const todo = mockData.find((todo) => todo.id == id);
        todo.completed = !todo.completed;
        return todo;
    })
}