var path = require('path');

module.exports = {
    entry:{
        demo: path.join(__dirname, '/src/app.js')
    },
    output:{
        path: __dirname+'/asserts',
        publicPath:'/asserts/',
        filename: 'bundle.js',
    },
    module:{
        loaders:[{
            test: /\.js$/,
            exclude: /(node_modules)/, //webpack打包的时候不打包exclude的内容
            loader: 'babel-loader', // 'babel-loader' is also a valid name to reference
            query: {
                presets: ['es2015', 'react']  //可以解析es2015和react语法
            }
        }]
    },
    devtool: 'cheap-eval-source-map'
}