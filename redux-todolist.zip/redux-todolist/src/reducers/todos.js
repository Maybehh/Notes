let gid = 0;
const todos = (state = [], action) => {
    switch(action.type) {  //纯函数因此不要直接在state上改，具体原因看源码（state要不同的地址，在redux里是根据state的地址即===来判断state是否更新，如果在原来基础上改且返回的话，地址不变，redux认为state没有变化，就不会更新state值，在渲染过程中获取的state值也就没变
        case 'ADD_TODO':
            // state.push({
            //     id: ++gid,
            //     text: action.text, //传进来的是对象的话，在外界改变对象则这里的对象也会改（引用值）就会引起数据混乱
            //     completed: false,
            //     test: Object.assign({}, action.test)  解决方法1
            // })

            // let newstate = [].concat(state);
            // newstate.push({
            //     id: ++gid,
            //     text: action.text,
            //     completed: false
            // });
            // return newstate;   //结合源码理解return后赋给了store的state值，state因此更新

            return [...state, {
                id: ++gid,
                text: action.text,
                completed: false
            }]
        case 'TOGGLE_TODO':
            return state.map((todo) => {
                if(todo.id == action.id) {
                    return Object.assign({}, todo, {
                        completed: !todo.completed
                    })
                }
                return todo;
            })
        default: 
            return state;
    }
}

export default todos;
