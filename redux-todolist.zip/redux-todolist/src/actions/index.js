export const addTodo = (val) => {
    return {
        type: 'ADD_TODO',
        text: val
    }
}

export const toggleTodo = (id) => {
    return {
        type: 'TOGGLE_TODO',
        id
    }
}

export const setVisiableFilter = (filter) => {
    return {
        type: 'SET_VISIABLEFILTER',
        filter
    }
}