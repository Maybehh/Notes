import React, {Component} from 'react';
import {connect} from 'react-redux';
import {setVisiableFilter} from '../actions/index.js';
import FilterLink from '../components/FilterLink.js';

class Footer extends Component{
    render() {
        return (
            <div>
                <FilterLink 
                    filter='SHOW_ALL' 
                    currentFilter={this.props.visiableFilter}
                    // onClick={() => {  //如果直接写this.props.onClickFilter('SHOW_ALL')则函数执行返回值是undefined，react会处理成内存泄漏
                    //     this.props.onClickFilter('SHOW_ALL');
                    // }}>
                    onClick={this.props.onClickFilter}>
                    Show all
                </FilterLink>
                {' '}
                <FilterLink 
                    filter='SHOW_COMPLETED' 
                    currentFilter={this.props.visiableFilter}
                    // onClick={() => {
                    //     this.props.onClickFilter('SHOW_COMPLETED');
                    // }}>
                    onClick={this.props.onClickFilter}>
                    Show completed
                </FilterLink>
                {' '}
                <FilterLink 
                    filter='SHOW_ACTIVE' 
                    currentFilter={this.props.visiableFilter}
                    // onClick={() => {
                    //     this.props.onClickFilter('SHOW_ACTIVE');
                    // }}>
                    onClick={this.props.onClickFilter}>
                    Show active
                </FilterLink>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        visiableFilter: state.visiableFilter
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onClickFilter: (filter) => {
            dispatch(setVisiableFilter(filter))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Footer);