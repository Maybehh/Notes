//index.js
//获取应用实例
var data = require('../../data/data.js');
Page({
  data: {
    longitude: 0,
    latitude: 0
  },
  bindcontroltap: function (e) {
    switch(e.controlId) {
      case 1:
        this.movetoCenter();
        break;
      case 2:
        if(this.timer) {
          wx.navigateBack({
            delta: 1  //返回上一层(页面栈)
          })
        } else {
          wx.scanCode({
            success: () => {
              wx.showLoading({
                title: '正在获取密码'
              })
              wx.request({
                url: 'https://easy-mock.com/mock/5f51215022b6925fcfc5d912/ofo/password',
                success: (res) => {
                  wx.hideLoading();
                  wx.redirectTo({
                    url: '../scanResult/index?password=' + res.data.data.password + '&number=' + res.data.data.number,
                    success: () => {
                      wx.showToast({
                        title: '获取密码成功',
                        duration: 1000
                      })
                    }
                  })
                }
              })
            },
            fail: () => {}
          })
        }
        break;
      case 3:
        wx.navigateTo({
          url: '../warn/index'
        });
        break;
      case 5:
        wx.navigateTo({
          url: '../my/index'
        })
      
    }
  },
  onLoad: function (options) { //this指向该小程序实例（Page())
    this.timer = options.timer;
    wx.getLocation({  //提供接口不算作用域
      // success: function(res) {  回调函数不是在这里面执行的而是拿出去执行，类似setTimeout，因此写this的话 this指向该回调函数
      //   this.setData({
      //       longtitude: res.longitude
      //   })
      // },
      success: (res) => {
        this.setData({
          longitude: res.longitude,
          latitude: res.latitude
        })
      }
    })
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          controls: [{
            id: 1,
            iconPath: "/images/location.png",
            position: {  //单位是px
              width: 50,
              height: 50,
              left: 20,
              top: res.windowHeight - 80
            },
            clickable: true
          },
          {
            id: 2,
            iconPath: "/images/scan.png",
            position: {  //单位是px
              width: 90,
              height: 90,
              left: res.windowWidth / 2 - 45,
              top: res.windowHeight - 100
            },
            clickable: true
          },
          {
            id: 3,
            iconPath: "/images/alerm.png",
            position: {  //单位是px
              width: 50,
              height: 50,
              left: res.windowWidth - 70,
              top: res.windowHeight - 80
            },
            clickable: true
          },
          {
            id: 5,
            iconPath: "/images/user.png",
            position: {  //单位是px
              width: 50,
              height: 50,
              left: res.windowWidth - 70,
              top: res.windowHeight - 155
            },
            clickable: true
          },
          {
            id: 4,
            iconPath: "/images/Favorit-Location.png",
            position: {  //单位是px
              width: 30,
              height: 45,
              left: res.windowWidth / 2 - 15,
              top: res.windowHeight / 2 - 45
            }
          }
        ]
        })
      },
    })
  },
  onShow: function () {
    this.mapctx = wx.createMapContext('ofo-map');
    this.movetoCenter();
  },
  movetoCenter: function () {
    this.mapctx.moveToLocation();
  }
})