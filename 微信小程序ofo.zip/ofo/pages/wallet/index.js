// pages/wallet/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ticket: 0,
    money: 0
  },
  movetoCharge: function () {
    wx.navigateTo({
      url: '../charge/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {  //回到该页（加载过，离开时没有删除，即用的是navigateto而不是redirecto）时是不会重新加载的，只执行onShow，只有从未加载过（或已经被删除了）才会执行onLoad然后执行onShow
    wx.getStorage({
      key: 'overage',
      success: (res) => {
        this.setData({
          money: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})