var obj = {
  password: {
    data: {
      password: 1234,
      number: 12345
    }
  },
  success: {
    data: {
      data: 123
    }
  }
}

module.exports = obj;