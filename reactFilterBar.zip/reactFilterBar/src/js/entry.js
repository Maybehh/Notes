var React = require('react');
var ReactDom = require('react-dom');

var PRODUCTS = [
    {category: 'Sporting Goods', price: '$49.99', stocked: true, name: 'Football'},
    {category: 'Sporting Goods', price: '$9.99', stocked: true, name: 'Baseball'},
    {category: 'Sporting Goods', price: '$29.99', stocked: false, name: 'Basketball'},
    {category: 'Electronics', price: '$99.99', stocked: true, name: 'iPod Touch'},
    {category: 'Electronics', price: '$399.99', stocked: false, name: 'iWatch'},
    {category: 'Electronics', price: '$199.99', stocked: true, name: 'iPad'},
];

var Input = React.createClass({
    getInitialState: function () {
        return {
            value: ''
        }
    },
    onHandleChange: function () {
        // 1、document.getElementById('demo')
        // 2、this.refs.inp同样可以获取input元素
        // this.setState({
        //     value: this.refs.inp.value
        // })
        this.setState({
            value: this.myInp.value
        })
    },
    render: function () {
        return (
            <div>
                <input value={this.state.value} /*1、id='demo' 可以通过id获取dom节点*/ 
                                                /*2、ref='inp'*/ 
                ref={function (dom) {this.myInp = dom}.bind(this)}  /*dom参数就是input元素，this指向Input组件*/
                type="text" onChange={this.onHandleChange}/>
                <span>{this.state.value}</span>
            </div>
        )
    }
});

var SearchBar = React.createClass({
    onHandleChange: function () {
        this.props.changeFilterText(this.refs.inp.value);
    },
    render: function () {
        return (
            <div>
                <input type="text" ref='inp' onChange={this.onHandleChange}/>
                <br/>
                <input type="checkbox" onClick={this.props.changeOnlyStocked}/>
                <span>onlyShowStocked</span>
            </div>
        )
    }
});

var ProductCategoryRow = React.createClass({
    render: function () {
        return (
            <tr style={{fontWeight: 900, color: '#0ff'}}>
                <td>{this.props.category}</td>
            </tr>
        )
    }
});

var ProductRow = React.createClass({
    render: function () {
        return (
            <tr style={this.props.stocked ? {} : {color: '#f00'}}>
                <td>{this.props.name}</td>
                <td>{this.props.price}</td>
            </tr>
        )
    }
});

var ProductTable = React.createClass({
    componentWillMount: function () { //componentWillMount只在装载时执行一次，改变state不会触发componentWillMount
        // var products = this.props.products;
        // var lastCategory = '';
        // var rows = [];
        // products.forEach(function (ele, index) {
        //     if(lastCategory !== ele.category) {
        //         rows.push(
        //             <ProductCategoryRow key={index} category={ele.category}></ProductCategoryRow>
        //         )
        //     }
        //     lastCategory = ele.category;
        //     rows.push(
        //         <ProductRow key={index + 1000} stocked={ele.stocked} name={ele.name} price={ele.price}></ProductRow>
        //     )
        // })
        // this.rows = rows;
        this.onHandleChange();
    },
    shouldComponentUpdate: function (nextProps, nextState) { //传的值得等到shouldComponentUpdate完成后才能更新到props里
        this.props = nextProps;
        this.onHandleChange();
        return true;
    },
    onHandleChange: function () {
        var products = this.props.products;
        var lastCategory = '';
        var rows = [];
        var _self = this;
        products.forEach(function (ele, index) {
            if(lastCategory !== ele.category) {
                rows.push(
                    <ProductCategoryRow key={index} category={ele.category}></ProductCategoryRow>
                )
            }
            lastCategory = ele.category;
            if(!_self.props.onlyShowStocked || (_self.props.onlyShowStocked && ele.stocked)) {
                if(ele.name.indexOf(_self.props.filterText) !== -1) {   
                    rows.push(
                        <ProductRow key={index + 1000} stocked={ele.stocked} name={ele.name} price={ele.price}></ProductRow>
                    )
                }
            }
        })
        this.rows = rows;
    },
    render: function () {
        return (
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.rows
                    }
                </tbody>
            </table>
        )
    }
});

var App = React.createClass({
    getInitialState: function () {
        return {
            onlyShowStocked: false,
            filterText: ''
        }
    },
    changeOnlyStocked: function () {
        this.setState({
            onlyShowStocked: !this.state.onlyShowStocked
        })
    },
    changeFilterText: function (text) {
        this.setState({
            filterText: text
        })
    },
    render: function () {
        return (
            <div>
                <SearchBar changeFilterText={this.changeFilterText} changeOnlyStocked={this.changeOnlyStocked}></SearchBar>
                <ProductTable filterText={this.state.filterText} onlyShowStocked={this.state.onlyShowStocked} products={this.props.products}></ProductTable>
            </div>
        )
    }
});

ReactDom.render(
    <App products={PRODUCTS}></App>,
    document.getElementById('root')
)