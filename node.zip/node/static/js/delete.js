$('.btn').on('click', function () {
    var id = $(this).attr('id');
    var self = $(this);
    $.ajax({
        url: '/admin/movie/delete',
        type: 'POST',
        data: {id: id},
        success: function (flag) {
            if(flag === 'success') {
                self.parents('tr').remove();
            }
        },
        error: function (err) {
            console.log(err);
        }
    })
})