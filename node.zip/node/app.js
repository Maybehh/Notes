var express  = require('express');
var path = require('path');
var app = express();
var serverStatic = require('serve-static');
var bodyParser = require('body-parser');  //处理post请求
var Movies = require('./mongoose/mongoModel.js');

app.set('views', './views/pages');
app.set('view engine', 'jade');

app.use(serverStatic(path.join(__dirname, 'static')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

// var movieIndexData = [{
//         id: 1,
//         title: 'nba总决赛',
//         poster: 'https://puui.qpic.cn/qqvideo_ori/0/m0198e4kvhs_496_280/0'
//     }, {
//         id: 2,
//         title: 'nba总决赛',
//         poster: 'https://puui.qpic.cn/qqvideo_ori/0/m0198e4kvhs_496_280/0'
//     }, {
//         id: 3,
//         title: 'nba总决赛',
//         poster: 'https://puui.qpic.cn/qqvideo_ori/0/m0198e4kvhs_496_280/0'
//     }, {
//         id: 4,
//         title: 'nba总决赛',
//         poster: 'https://puui.qpic.cn/qqvideo_ori/0/m0198e4kvhs_496_280/0'
//     }, {
//         id: 5,
//         title: 'nba总决赛',
//         poster: 'https://puui.qpic.cn/qqvideo_ori/0/m0198e4kvhs_496_280/0'
//     }, {
//         id: 6,
//         title: 'nba总决赛',
//         poster: 'https://puui.qpic.cn/qqvideo_ori/0/m0198e4kvhs_496_280/0'
//     },
// ]
// var movieDetailData = {
//     id: 1,
//     director: 'cst',
//     country: '美国',
//     title: 'nba',
//     year: 2013,
//     poster: '',
//     language: '英语',
//     summary: '2013年，nba总决赛，热火对战马刺，这是一场精彩绝伦的总决赛，詹姆斯',
//     address: '/video/node.mp4'
// }

app.post('/admin/movie/new', function (req, res) {
    var movieMessageObj = req.body;  //post的数据经过body-parser会到req.body里
    var newMovie = new Movies({
        // 存完后数据库会自动给一个_id
        director: movieMessageObj.director,
        title: movieMessageObj.title,
        language: movieMessageObj.language,
        country: movieMessageObj.country,
        year: movieMessageObj.year,
        summary: movieMessageObj.summary,
        address: movieMessageObj.address,
        poster: movieMessageObj.poster,
    });
    //把数据写入数据库
    newMovie.save(function (err, movie) {
        if(err) {
            console.log(err);
            return;
        }
        res.redirect('/movie/' + id);
    })
})

app.get('/', function (req, res) {
    Movies.find({}, function (err, data) {  //拿到数据库所有数据渲染
        if(err) {
            console.log(err);
            return;
        }
        res.render('index', {  //有render或end就不会一直转
            title: 'NBA',
            movieArray: data
        })
    })
})

app.get('/admin/movie', function (req, res) {
    res.render('admin.jade', {
        title: 'Add Page'
    })
})

app.get('/movie/:id', function (req, res) {
    var id = req.params.id;
    Movies.findById({_id: id}, function (err, singleMovie) {
        if(err) {
            console.log(err);
            return;
        }
        res.render('detail', {
            movie: singleMovie
        })
    })
})

app.post('/admin/movie/delete', function (req, res) {
    var id = req.body.id;
    Movies.remove({_id: id}, function (err, movie) {
        if(err) {
            console.log(err);
            return;
        }
        res.end('success');
    })
})

app.get('/admin/list', function (req, res) {
    Movies.find({}, function (err, data) {  //拿到数据库所有数据渲染
        if(err) {
            console.log(err);
            return;
        }
        res.render('list', {
            movieArray: data
        })
    })
})
app.listen(3000);