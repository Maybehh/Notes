var mongoose = require('mongoose');
var Schema = require('./mongoSche.js');
mongoose.Promise = global.Promise;

//链接数据库
var db = mongoose.createConnection('localhost', 'test');

var Movies = db.model('Movies', Schema);

module.exports = Movies;