var mongoose = require('mongoose');
var Schema = new mongoose.Schema({  //图纸
    id: Number,
    director: String,
    title: String,
    language: String,
    country: String,
    year: String,
    summary: String,
    address: String,
    poster: String,
    upDateTime: String
});

Schema.pre('save', function (next) {
    this.upDateTime = new Date();
    next();
});

module.exports = Schema;