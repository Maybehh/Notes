(function () {
    var $search = $('.search'),
        $ul = $('ul', '.nav-list');
    console.log($search);
    $search.on('input', function () {
        var value = $(this).val();
        console.log(value)
        getData(value, 7);
    })

    function getData(value, num) {
        $.ajax({
            type: 'GET',
            url: 'https://api.douban.com/v2/music/search',
            data: 'q=' + value + '&count=' + num,
            dataType: 'jsonp',
            success: addItem,
        })
    }
    function addItem(data) {
        console.log(data);
        var list = data.musics;
        var str = '';
        list.forEach(function (ele, index) {
            str += '<li><a href="https://music.douban.com/subject/' + ele.id + '"><img src="' + ele.image + '"></a></li>';
        })
        $ul.html($(str));
    }
})()

//分页：第几页根据start开始显示
//跳转到自己的页面：根据url加上每个音乐独特的id，在自己的页面的js再发请求，获取信息后，在自己的页面进行渲染