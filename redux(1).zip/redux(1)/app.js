// import {createStore} from 'redux';

const counter = (state=0, action) => {
    // if(state == undefined) {
    //     state = 0;
    // }
    switch(action.type) {
        case 'INCREASE':
            return state + 1;
        case 'DECREASE':
            return state - 1;
        default:
            return state;
    }
}

const createStore = (reducer) => {
    let state;
    let list = [];
    const getState = () => {
        return state;
    }
    const dispatch = (action) => {
        state = reducer(state, action);
        list.forEach((fn) => {
            fn();
        })
    }
    const subscribe = (fn) => {
        list.push(fn);
        return () => {
            list = list.filter(cb => cb != fn)
        }
    }
    return {
        getState,
        subscribe,
        dispatch
    }
}

const store = createStore(counter);
store.dispatch({
    type: 'INIT'  //不一定叫INIT，就是在createStore后，系统会自动dispatch一个初始化action（随便弄一个一般不会想到的type让reducer实现default让state附上默认值）让state拥有设定的默认值而不是undefined
})

const render = () => {
    // document.write('<h1>' + store.getState() + '</h1>');  //document.write会重写document，会把之前在document上加的东西全部清除，因此把监听事件也去除了，因此再次点击无效
    document.getElementsByTagName('body')[0].innerHTML = '<h1>' + store.getState() + '</h1>';
}

const unsubscribe = store.subscribe(render);  //每次dispatch后就会执行render函数

render();

document.addEventListener('click', () => {
    store.dispatch({
        type: 'INCREASE'
    });
    unsubscribe();  //取消订阅的函数
})