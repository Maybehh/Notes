import React from 'react';
import App from '../containers/App.js';
import {Provider} from 'react-redux';

const Root = ({store}) => (
    <Provider store={store}>
        <App></App>
    </Provider>
)

export default Root;