import React, {Component} from 'react';
import {connect} from 'react-redux';

class Search extends Component{
    onHandleChange() {
        this.props.onSetFilter(this.input.value);
    }
    render() {
        var data = this.props.list;
        var personRow = [];
        var truePerson = [];

        data.forEach(function (item, index) {
            if(item.invited && index < 2) {
                personRow.unshift(<span key={index + 100}>{item.name}</span>);
                truePerson = personRow;
            }else if (item.invited && index >=2){
                personRow.unshift(<span key={index + 100}>{item.name}</span>);
                truePerson = personRow.slice(0, 2);
            }
        })
        return (
            <div className="searchBar">
                <input ref={(c) => {this.input = c}} type="text" placeholder='搜索你想要要邀请的人' onChange={() => {this.onHandleChange()}}/>
                <span>您已邀请{truePerson}等{personRow.length}人</span>
            </div>
        )
    }
}

const mapStateToProps = (state) => ({
    list: state.list
})

const mapDispatchToProps = (dispatch) => ({
    onSetFilter: (filter) => {
        dispatch({
            type: 'SET_FILTER',
            filter
        })
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(Search);