import React from 'react';
import Item from '../components/Item.js';
import {connect} from 'react-redux';

const List = ({list, onToggleInvite}) => {
    const row = list.map((item) => 
    <Item 
        key={item.id}
        person={item}
        onChangeInvited={onToggleInvite}
    ></Item>)
    return (
        <div className="listWrapper">
            <ul>
                {row}
            </ul>
        </div>
    )
}

const getVisibleList = (list, filter) => list.filter((item) => item.name.indexOf(filter));

const mapStateToProps = (state) => ({
    list: getVisibleList(state.list, state.filter)
})

const mapDispatchToProps = (dispatch) => ({
    onToggleInvite: (id) => {
        dispatch({
            type: 'TOGGLE_INVITE',
            id
        })
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(List);