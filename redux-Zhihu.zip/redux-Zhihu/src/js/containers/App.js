import React, {Component} from 'react';
import List from './List.js';
import Search from './Search.js';
import {connect} from 'react-redux';
import {fetchList} from '../api/fetchList';

// const App = ({onReceiveList}) => (  //{return 1}相当于写(1)
//     <div>
//         <Search></Search>
//         <List></List>
//     </div>
// )

class App extends Component{
    componentDidMount() {
        const data = fetchList();
        this.props.onReceiveList(data.invited);
    }
    render() {
        return (
            <div className="wrapper">
                <Search></Search>
                <List></List>
            </div>
        )
    }
}

const mapDispatchToProps = (dispatch) => ({
    onReceiveList: (list) => {
        dispatch({
            type: 'RECEIVE_LIST',
            list
        })
    }
})

export default connect(null, mapDispatchToProps)(App);