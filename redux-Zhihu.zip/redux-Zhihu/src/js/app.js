import React from 'react';
import ReactDom from 'react-dom';
import Root from './components/Root.js';
import {createStore} from 'redux';
import rootReducer from './reducers/';
import '../less/entry.less';

const store = createStore(rootReducer);

ReactDom.render(
    <Root store={store}></Root>,
    document.getElementById('root')
)