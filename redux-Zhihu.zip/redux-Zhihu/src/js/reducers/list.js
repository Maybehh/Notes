const list = (state = [], action) => {
    switch(action.type) {
        case 'TOGGLE_INVITE':
            return state.map((item) => {
                if(item.id == action.id) {
                    return Object.assign({}, item, {
                        invited: !item.invited
                    });
                }
                return item;
            })
        case 'RECIVE_LIST': 
            return action.list;
        default: 
            return state;
    }
}

export default list;