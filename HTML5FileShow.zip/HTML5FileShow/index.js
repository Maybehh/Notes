//阻止浏览器默认行为
$(document).on({
    dragleave: function (e) {  //拖离
        e.preventDefault();
    },
    drop: function (e) {   //拖后放
        e.preventDefault();
    },
    dragenter: function (e) {  //拖进
        e.preventDefault();
    },
    dragover: function (e) {  //拖来拖去
        e.preventDefault();
    }
});
var box = document.getElementById('drop_area');
box.addEventListener('drop', function (e) {
    e.preventDefault();
    var fileList = e.dataTransfer.files;
    console.log(fileList);

    if(fileList.length == 0) {
        return false;
    }

    if(fileList[0].type.indexOf('image') === -1) {
        alert('您拖的不是图片！');
        return false;
    }

    var img = window.URL.createObjectURL(fileList[0]);  //生成图片信息，64位base
    console.log(img);
    var filename = fileList[0].name;
    var filesize = Math.floor((fileList[0].size) / 1024);
    if(filesize > 500) {
        alert('上传大小不能超过500K.');
        return false;
    }
    var str = "<img src='" + img + "'><p>图片名称：" + filename + "</p><p>大小：" + filesize;
    $('#preview').html(str);
    //上传
    var fd = new FormData();
    fd.append('mypic', FileList[0]);

    // ajax('post', 'upload.php', function () {
    //       console.log('success');
    // }, fd, true);
}, false);