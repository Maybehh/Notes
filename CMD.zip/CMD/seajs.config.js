seajs.config({
    alias: {
        'math': './main.js'
    }
})