define(function (require, exports, module) {
    function add(a, b) {
        return a + b;
    }
    exports.add = add;
    exports.str = "123";
})