define(function (require, exports, module) {
    var math = require('math.js');
    console.log(math.add(1, 2));
    console.log(math.str);
})