onmessage = function (e) {
    console.log(e.data);
    // close();
    postMessage(deal(e.data));
}

function deal(data) {
    return data * data;
}